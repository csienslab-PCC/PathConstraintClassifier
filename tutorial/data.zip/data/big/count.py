import sys

binary=sys.argv[1]
depth=sys.argv[2]
solvers_list=["msat","cvc4","btor","z3"]
solver_count={}
solver_count['default']=0
solver_time={}
for i in solvers_list:
	solver_count[i]=0

state=0
totaltime=0
while True:
	try:
		f=open(binary+"con_"+depth+"_"+str(state)+".result").readlines()[0].split(":")[1]
		state+=1
		#print f
		totaltime+=float(f)
		#print totaltime
	except:
		break
#for i in solver_count:
	#print i,solver_count[i]
		
print totaltime
